from flask import Flask, render_template, request
import re

app = Flask(__name__)


@app.route('/')
def check():
    """
    Een check voor of het dna, rna of eiwit is
    :return:
    """
    if request.method == 'GET':
        # de regex om te kijken of het DNA, RNA of eiwit is
        seq = request.values.get("seq", "")
        dna = re.search(r"[^A.T.C.G]", seq)
        rna = re.search(r"[^A.U.C.G]", seq)
        eiwit = re.search(r"[^Q.W.E.R.Y.I.P.A.S.D.F.G.H.K.L.C.V.N.M.T]{100}", seq)
        # geeft door of het wel of niet DNA, RNA of eiwit is
        if dna:
            dna_true = "geen DNA sequentie"
        else:
            dna_true = "Dit is een DNA sequentie"
        if rna:
            rna_true = "geen RNA sequentie"
        else:
            rna_true = "Dit is een RNA sequentie"
        if eiwit:
            eiwit_true = "geen eiwit sequentie"
        else:
            eiwit_true = "Dit is een eiwit sequentie"

        return render_template("page.html", dna_true=dna_true,
                               rna_true=rna_true, eiwit_true=eiwit_true)


if __name__ == '__main__':
    app.run()
